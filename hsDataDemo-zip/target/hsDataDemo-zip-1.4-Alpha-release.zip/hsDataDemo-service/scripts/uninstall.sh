#!/bin/bash

rm -rf ${workspace}/${app_name}